from ..model import Model
from ..cloud import Cloud
import matplotlib.pyplot as plt
import numpy

def test_instantiate() :
    aModel= Model()

    assert( type( aModel ) is Model )
    assert( type( aModel.estimate( 10.5 ) ) is float )
    assert( type( aModel.randError() ) is float )

    aCloud= aModel.generateCloud( 100 )
    assert( type(aCloud) is Cloud )
    assert( len( aCloud.points() ) == 100 )
    assert( aCloud.size() == 100 )
    for i in range(100) :
        assert( len(aCloud.point(i)) == 2 )
        assert( type(aCloud.point(i)[0]) is numpy.float64 )
        assert( type(aCloud.point(i)[1]) is numpy.float64 )

def test_modelIdentity() :
    aModel= Model()

    for x in [ 10.0, 23.0, 4.5, -128.0008 ] :
        assert( aModel.estimate( x ) == x )
    
    lastError= -1
    for i in range(10000) :
        error= aModel.randError()
        assert( -10 <= error and error < 10 )
        assert( error != lastError )
        lastError = error

    assert( round( aModel.signError(10.5, 10.5), 2) == 0.00 )
    assert( round( aModel.signError(10.5, 11.5), 2) == 1.00 )
    assert( round( aModel.signError(10.5, 9.3), 2)  == -1.20 )

    assert( round( aModel.error(10.5, 10.5), 2) == 0.00 )
    assert( round( aModel.error(10.5, 11.5), 2) == 1.00 )
    assert( round( aModel.error(10.5, 9.3), 2)  == 1.20 )

def test_cloud() :
    aModel= Model()

    aCloud= Cloud()
    aCloud.set( [
        [10.5, 2.3],
        [2.4, 2.7],
        [5.5, 12.8],
        [7.5, 6.3]
    ] )

    assert( aModel.estimateModelParrameters( aCloud ) == [] )
    errors= aModel.errorList(aCloud)
    assert( [ round(r, 2) for r in errors ] == [8.2, 0.3, 7.3, 1.2] )
    assert( round(aModel.errorAverage(aCloud), 2) == 4.25 )

def test_plot() :
    aModel= Model( 10.0 )
    aCloud= aModel.generateCloud( 100 )
    plt.plot( aCloud.listX(), aCloud.listY(), color='blue', marker='o', linestyle=' ')
    
    #plt.plot( [  ], [ aa*-10+bb, aa*110+bb], color='blue', label="generator")
    #plt.plot( [-10, 110], [ a*-10+b, a*110+b], color='red', label="estimation")

    plt.plot( [float(x) for x in range(-10, 110)],
             [ aModel.estimate( float(x) ) for x in range(-10, 110)],
             color='red', label="model")

    plt.legend()

    plt.xlabel( f"error: { round( aModel.errorAverage( aCloud ), 2) }" )

    plt.savefig('test_img_model01.png')  
    plt.clf()

    assert("True")
