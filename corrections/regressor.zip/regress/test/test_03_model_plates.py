from ..model import ModelPlates
from ..cloud import Cloud
import matplotlib.pyplot as plt
import numpy

def test_instantiate() :
    aModel= ModelPlates()

    assert( type( aModel ) is ModelPlates )
    assert( type( aModel.estimate( 10.5 ) ) is float )
    assert( type( aModel.randError() ) is float )

    aCloud= aModel.generateCloud( 100 )
    assert( type(aCloud) is Cloud )
    assert( len( aCloud.points() ) == 100 )
    assert( aCloud.size() == 100 )
    for i in range(100) :
        assert( len(aCloud.point(i)) == 2 )
        assert( type(aCloud.point(i)[0]) is numpy.float64 )
        assert( type(aCloud.point(i)[1]) is numpy.float64 )

