from ..cloud import Cloud
import numpy
import matplotlib.pyplot as plt

def test_instantiate() :
    aCloud= Cloud().setAtRandom( 100 )
    assert( type(aCloud) is Cloud )
    assert( aCloud.size() == 100 )
    for i in range(100) :
        assert( len(aCloud.point(i)) == 2 )
        assert( type(aCloud.point(i)[0]) is numpy.float64 )
        assert( type(aCloud.point(i)[1]) is numpy.float64 )

def test_accessors() :
    aCloud= Cloud()
    aCloud.set( [
        [10.5, 2.3],
        [2.4, 2.7],
        [5.5, 12.8],
        [7.5, 0.3]
    ] )

    assert( aCloud.size() == 4 )
    assert( aCloud.point(0) == [10.5, 2.3] )
    assert( aCloud.point(1) == [2.4, 2.7] )
    assert( aCloud.point(3) == [7.5, 0.3] )

    assert( aCloud.listX() == [10.5, 2.4, 5.5, 7.5] )
    assert( aCloud.listY() == [2.3, 2.7, 12.8, 0.3] )

def test_string() :
    aCloud= Cloud()
    aCloud.set( [
        [10.5, 2.3],
        [2.412, 2.709],
        [5.5, 12.8],
        [7.5, 0.3]
    ] )

    assert( aCloud.pointStr(0) == "(10.5, 2.3)" )
    assert( aCloud.pointStr(1) == "(2.4, 2.7)" )
    assert( aCloud.pointStr(3) == "(7.5, 0.3)" )

    print( aCloud )
    assert( str(aCloud) == "[(10.5, 2.3), (2.4, 2.7), ...](4)" )

def test_tools() :
    aCloud= Cloud()
    aCloud.set( [
        [10.5, 2.3],
        [2.412, 2.709],
        [5.5, 12.8],
        [7.5, 0.3]
    ] )

    assert( aCloud.average() == [6.478, 4.52725] )
    assert( round(aCloud.standardDeviation(), 2) == 11.37 )

def test_search() :
    aCloud= Cloud()
    aCloud.set( [
        [10.5, 2.3],
        [2.412, 2.709],
        [5.5, 12.8],
        [8.5, 0.3]
    ] )

    assert( aCloud.minXpoint() == [2.412, 2.709] )
    assert( aCloud.maxXpoint() == [10.5, 2.3] )
    extrem1, extrem2= aCloud.extrem()
    assert( extrem1 in ([8.5, 0.3], [5.5, 12.8]) )
    assert( extrem2 in ([8.5, 0.3], [5.5, 12.8]) )
    assert( extrem1 != extrem2 )

def test_plot() :
    aCloud= Cloud().setAtRandom( 100 )
    plt.plot( aCloud.listX(), aCloud.listY(), color='green', marker='o', linestyle=' ')
    plt.legend()
    plt.savefig('test_img_cloud01.png')  
    plt.clf()
    assert("True")
