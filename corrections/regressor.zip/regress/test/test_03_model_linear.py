from ..model import ModelLinear
from ..cloud import Cloud
import matplotlib.pyplot as plt
import numpy

def test_instantiate() :
    aModel= ModelLinear()

    assert( type( aModel ) is ModelLinear )
    assert( type( aModel.estimate( 10.5 ) ) is float )
    assert( type( aModel.randError() ) is float )

    aCloud= aModel.generateCloud( 100 )
    assert( type(aCloud) is Cloud )
    assert( len( aCloud.points() ) == 100 )
    assert( aCloud.size() == 100 )
    for i in range(100) :
        assert( len(aCloud.point(i)) == 2 )
        assert( type(aCloud.point(i)[0]) is numpy.float64 )
        assert( type(aCloud.point(i)[1]) is numpy.float64 )

def test_modelIdentity() :
    aModel= ModelLinear()

    for x in [ 10.0, 23.0, 4.5, -128.0008 ] :
        assert( round( aModel.estimate( x ), 4 ) == round( x, 4 ) )
    
    assert( round( aModel.signError(10.5, 10.5), 2) == 0.00 )
    assert( round( aModel.signError(10.5, 11.5), 2) == 1.00 )
    assert( round( aModel.signError(10.5, 9.3), 2)  == -1.20 )

    assert( round( aModel.error(10.5, 10.5), 2) == 0.00 )
    assert( round( aModel.error(10.5, 11.5), 2) == 1.00 )
    assert( round( aModel.error(10.5, 9.3), 2)  == 1.20 )

def test_modelAB() :
    aModel= ModelLinear( 2.0, 1.0 )

    for x in [ 10.0, 23.0, 4.5, -128.0008 ] :
        assert( round( aModel.estimate( x ), 4 ) == round( 2.0*x + 1.0, 4 ) )
    
    assert( round( aModel.signError(10.5, 22.0), 2) == 0.00 )
    assert( round( aModel.signError(10.5, 23.0), 2) == 1.00 )
    assert( round( aModel.signError(10.5, 20.8), 2)  == -1.20 )

    assert( round( aModel.error(10.5, 22.0), 2) == 0.00 )
    assert( round( aModel.error(10.5, 23.0), 2) == 1.00 )
    assert( round( aModel.error(10.5, 20.8), 2)  == 1.20 )

def test_modelEstimation() :
    aModel= ModelLinear()

    aCloud= Cloud()
    aCloud.set( [
        [2.4, 2.7],
        [7.5, 12.3],
        [20.4, 40.8],
        [44.5, 60.8],
        [59.3, 131.0]
    ] )

    aModel.firstEstimation( aCloud )

    plt.plot( aCloud.listX(), aCloud.listY(), color='blue', marker='o', linestyle=' ')

    plt.plot( [float(x) for x in range(-10, 110)],
             [ aModel.estimate( float(x) ) for x in range(-10, 110)],
             color='green', label= f"model-first{ round(aModel.errorAverage( aCloud ), 2) }")
    
    assert( round(aModel.errorAverage(aCloud), 2) < 8.3 )

    isOptimization= True
    count= 0
    while isOptimization :
        isOptimization= ( aModel.optimizeA( aCloud, 0.1 )
            or aModel.optimizeB( aCloud, 0.1 ) )
        count+= 1
    
    print( f"Optimisation: {count}" )

    plt.plot( [float(x) for x in range(-10, 80)],
             [ aModel.estimate( float(x) ) for x in range(-10, 80)],
             color='red', label="model-optimized")

    plt.legend()
    plt.xlabel( f"parrameters: { aModel.parameters() }  error: { round( aModel.errorAverage( aCloud ), 2) }" )
    plt.savefig('test_img_linear01.png')  
    plt.clf()

    assert( round(aModel.errorAverage(aCloud), 2) < 8.00 )

def test_modelEstimation2() :
    aModel= ModelLinear( 1.2, -2, 10.0 )
    aCloud= aModel.generateCloud( 100 )

    plt.plot( aCloud.listX(), aCloud.listY(), color='blue', marker='o', linestyle=' ')

    plt.plot( [float(x) for x in range(-10, 110)],
             [ aModel.estimate( float(x) ) for x in range(-10, 110)],
             color='blue', label= f"model-gen ({ round(aModel.errorAverage( aCloud ), 2) })")
    
    aModel.firstEstimation( aCloud )

    plt.plot( [float(x) for x in range(-10, 110)],
             [ aModel.estimate( float(x) ) for x in range(-10, 110)],
             color='green', label= f"model-first ({ round(aModel.errorAverage( aCloud ), 2) })")
    
    param= aModel.estimateModelParrameters( aCloud ) 

    assert( 1.15 < param[0] and param[0] < 1.25 )
    #assert( 1.98 < param[1] and param[1] < 2.02 )

    plt.plot( [float(x) for x in range(-10, 110)],
             [ aModel.estimate( float(x) ) for x in range(-10, 110)],
             color='red', label= f"model-estim ({ round(aModel.errorAverage( aCloud ), 2) })")

    plt.legend()
    plt.xlabel( f"parrameters: { [round(x, 2 ) for x in aModel.parameters()] }  error: { round( aModel.errorAverage( aCloud ), 2) }" )
    plt.savefig('test_img_linear02.png')  
    plt.clf()

    assert( round(aModel.errorAverage(aCloud), 2) < 8.00 )

