import random
from .cloud import Cloud

class Model :
    # Model permit to estimate an y value from a x (and an error).
    # basic model is identity: y= x.

    # initialization:
    def __init__(self, errorScale= 10.0):
        self._errorScale= errorScale

    # Accessors:
    def parameters(self):
        return []
    
    # y estimation:
    def estimate(self, x):
        return float(x)
    
    # error estimation:
    def error( self, x, y ):
        return abs( y - self.estimate(x) )
    
    def signError( self, x, y ):
        return y - self.estimate(x)
    
    def errorList(self, aPointCloud):
        return [ self.error( p[0], p[1] ) for p in aPointCloud.points() ]
    
    def errorAverage(self, aPointCloud):
        return sum( self.errorList(aPointCloud)) / aPointCloud.size()
    
    # error generator:
    def generateCloud( self, size) :
        aListOfPoints= []
        for i in range(size) :
            x= random.random() * 100.0
            y= self.estimate(x) + self.randError()
            aListOfPoints.append( [x, y] )
        return Cloud().set( aListOfPoints )

    # error generator:
    def randError( self ):
        return -self._errorScale + random.random()*self._errorScale*2
    
    # Model computation:
    def estimateModelParrameters(self, aPointCloud):
        # Should use aPointCloud to estimate 
        # and to return the list of model parrameters.
        # Basic model has no parrameters
        return []
    
class ModelLinear(Model) :

    # initialization:
    def __init__(self, a= 1.0, b= 0.0, errorScale= 10.0):
        super().__init__( errorScale )
        self._a= a
        self._b= b

    # Accessors:
    def parameters(self):
        return [self._a, self._b]

    # y estimation:
    def estimate(self, x):
        return self._a * x + self._b
    
    # Model computation:
    def estimateModelParrameters(self, aPointCloud, epsilon=0.001):
        # Compute a first estimation
        self.firstEstimation( aPointCloud )

        # Optimize by decrezing the step.
        step= 1.0
        while step > epsilon : 
            step/= 2
            isOptimization= True
            while isOptimization :
                isOptimization= ( self.optimizeA( aPointCloud, step )
                    or self.optimizeB( aPointCloud, step ) )
        return [self._a, self._b]
    
    def firstEstimation(self, aPointCloud):
        ex1, ex2= aPointCloud.extrem()
        self._a= (ex2[1]-ex1[1]) / (ex2[0]-ex1[0])
        self._b= ex1[1] - self._a*ex1[0]
        return [self._a, self._b]
    
    def optimizeA(self, aPointCloud, step):
        optionsA= [ self._a-step, self._a+step ]
        best= self._a
        minError= self.errorAverage( aPointCloud )
        isOptimization= False
        for a in optionsA :
            self._a= a
            test= self.errorAverage( aPointCloud )
            if test < minError :
                best= a
                isOptimization= True
        self._a= best
        return isOptimization
    
    def optimizeB(self, aPointCloud, step):
        optionsB= [ self._b-step, self._b+step ]
        best= self._b
        minError= self.errorAverage( aPointCloud )
        isOptimization= False
        for b in optionsB :
            self._b= b
            test= self.errorAverage( aPointCloud )
            if test < minError :
                best= b
                isOptimization= True
        self._b= best
        return isOptimization
    
class ModelPlates() :
    pass