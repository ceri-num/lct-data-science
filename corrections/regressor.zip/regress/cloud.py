import math, random, numpy as np

class Cloud :
    # Constructor:
    def __init__( self, aListOfPoints=[ [0.0, 0.0], [1.0, 1.0] ] ) :
        self.set( aListOfPoints )

    # Construction:
    def set( self, aListOfPoints ):
        self._points= np.array( aListOfPoints )
        self._size= len( self._points )
        return self

    def setAtRandom( self, size=2 ) :
        self._size= size
        self._points= np.array( [
            [random.random()*100, random.random()*100]
            for i in range(self._size)
        ] )
        return self

    # Accessor:
    def size(self):
        return self._size
    
    def points(self):
        return self._points
    
    def point(self, i):
        return list( self._points[i] )

    def listX(self):
        return [ p[0] for p in self._points ]
    
    def listY(self):
        return [ p[1] for p in self._points ]

    # Tools:
    def average( self ):
        return [
            sum( self.listX() ) / self.size(),
            sum( self.listY() ) / self.size()
        ]
    
    def distanceSquare( self, pi, pj ):
        return pow( pj[0]-pi[0], 2 ) + pow( pj[1]-pi[1], 2 ) 

    def standardDeviation( self ):
        av= self.average()
        variance= 0
        for p in self.points() :
            variance+= self.distanceSquare( av, p )
        return math.sqrt( variance )

    # Search:
    def minXpoint(self):
        minI= 0
        for i in range( 1, self.size() ) :
            if( self.point(i)[0] < self.point(minI)[0] ) :
                minI= i
        return self.point(minI)
    
    def maxXpoint(self):
        minI= 0
        for i in range( 1, self.size() ) :
            if( self.point(i)[0] > self.point(minI)[0] ) :
                minI= i
        return self.point(minI)

    def extrem(self):
        assert( self.size() > 2 )
        # Initialize 2 points as extrems
        ex1= self.point(0)
        ex2= self.point(1)
        refDist= self.distanceSquare( ex1, ex2 )
        # for each other points:
        for pi in self._points[2:] :
            d1= self.distanceSquare( ex1, pi )
            d2= self.distanceSquare( pi, ex2 )
            # if the distance to one of the extrem is greater...
            if d1 > refDist and d1 > d2 :
                ex2= list(pi)
                refDist= d1
            elif d2 > refDist :
                ex1= list(pi)
                refDist= d2
        # return the tuple of extrem points
        return ex1, ex2

    # String:
    def pointStr(self, i):
        p= self._points[i]
        return f"({round(p[0], 1)}, {round(p[1], 1)})"

    def __str__(self):
        s= self.size()
        if s == 0 :
            return "[](0)"
        elif s == 1 :
            return f"[{self.pointStr(0)}](1)"
        elif s == 2 :
            return f"[{self.pointStr(0)}, {self.pointStr(1)}](2)"
        return f"[{self.pointStr(0)}, {self.pointStr(1)}, ...]({s})"

