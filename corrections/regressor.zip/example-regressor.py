from regress.model import ModelLinear
import matplotlib.pyplot as plt

aModel= ModelLinear( 0.4, -8, 10.0 )
aCloud= aModel.generateCloud( 100 )

plt.plot( aCloud.listX(), aCloud.listY(), color='blue', marker='o', linestyle=' ')
plt.plot( [float(x) for x in range(-10, 110)],
        [ aModel.estimate( float(x) ) for x in range(-10, 110)],
        color='green', label= f"generator")

genError= round(aModel.errorAverage( aCloud ), 2)

param= aModel.estimateModelParrameters( aCloud ) 

plt.plot( [float(x) for x in range(-10, 110)],
        [ aModel.estimate( float(x) ) for x in range(-10, 110)],
        color='red', label="estimation")

estimError= round(aModel.errorAverage( aCloud ), 2)

plt.legend()
plt.xlabel( f"Generator error: {genError}, Estimation error: {estimError}" )

plt.show()
plt.clf()
